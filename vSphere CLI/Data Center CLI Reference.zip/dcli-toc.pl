#!/usr/bin/perl -w

if ($#ARGV < 0) {
  print "Usage: dcli-toc.pl index.html\n";
  print " Creates Eclipse toc.xml from DCLI doc in HTML.\n";
  exit
}

print '<?xml version="1.0" encoding="utf-8"?>', "\n";
print '<?NLS TYPE="org.eclipse.help.toc"?>', "\n";
print "<toc label=\"DCLI Reference\" topic=\"toc.xml\">\n";
print "<topic label=\"dcli com vmware\">\n" ;

if (-e "index.html") {
  open (IXFILE, "index.html") ;
  while (<IXFILE>) {
	if ($_ =~ /<li>/ ) {
		s/<li><a/  <topic/ ;
		s/target=\"_parent">/label=\"/ ;
		s/dcli com vmware // ;
		s/<\/a>/\"/ ;
		s/<\/li>/ \/>/ ;
		print $_ ;
	}
   }
}
print "<\/topic>\n</toc>\n" ;
